package com.example.uberrider.Callback;

public interface IFirebaseFailedListener {
    void onFirebaseLoadFailed(String message);
}
